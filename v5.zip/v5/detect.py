import torch
import torch.onnx
import torchvision
import torchvision.models as models
import cv2
import numpy as np

# Assuming Flatten module is defined correctly as before
class Flatten(torch.nn.Module):
    def forward(self, x):
        return x.view(x.size(0), -1)

def fix_model(model_dir, onnx_model_path):
    model = torch.load(model_dir, map_location=torch.device('cpu'))
    model.eval()

    # Adjust dummy_input to match the expected input shape of your model
    dummy_input = torch.randn(1, 3, 100, 100)  # assuming your model expects 3-channel 256x256 images
    torch.onnx.export(model, dummy_input, onnx_model_path, verbose=True)

def load_model(onnx_model_path, sample_image):
    model = cv2.dnn.readNetFromONNX(onnx_model_path)
    image = cv2.imread(sample_image)
    blob = cv2.dnn.blobFromImage(image, 1, (100, 100), (0, 0, 0), swapRB=True, crop=False)
    model.setInput(blob)
    preds = model.forward()
    biggest_pred_index = np.array(preds)[0].argmax()
    print("Predicted Class:", biggest_pred_index)

model_dir = r"C:\Users\adrian\Documents\IST_Assement\Software\v5\model.pth"
onnx_model_path = r"C:\Users\adrian\Documents\IST_Assement\Software\v5\onnxmodel.onnx"
sample_image = r"C:\Users\adrian\Documents\IST_Assement\Software\v5\test_image_2.jpg"

fix_model(model_dir, onnx_model_path)
load_model(onnx_model_path, sample_image)