import random
import pandas as pd
import numpy as np
import torchvision
import torch
from torch import nn
from torch.autograd import Variable
from sklearn.model_selection import train_test_split
from torchvision import transforms
from torchvision.datasets import ImageFolder
import matplotlib.pyplot as plt
import cv2
from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score

#Load Data
transforms_train = transforms.Compose([transforms.ToTensor(), transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])])
image_data_train = ImageFolder("./training_cut/", transform=transforms_train) #Specify Training Data Dir
image_data_test = ImageFolder("./test_cut", transform=transforms_train) #Specify Validation Image Dir

#Shuffle data to train properly
random.shuffle(image_data_train.samples)
random.shuffle(image_data_test.samples)

#Total Classes
classes_idx = image_data_train.class_to_idx
classes = len(image_data_train.classes)
len_train_data = len(image_data_train)
len_test_data = len(image_data_test)

def get_labels():
    labels_train = []
    labels_test = []

    for i in image_data_train.imgs:
        labels_train.append(i[1])

    for j in image_data_test.imgs:
        labels_test.append(j[1])

    return (labels_train, labels_test)

labels_train, labels_test = get_labels()

train_loader = DataLoader(dataset=image_data_train, batch_size=100)
test_loader = DataLoader(dataset=image_data_test, batch_size=100)

print(next(iter(train_loader))[0].shape)
record = next(iter(train_loader))[0]

#Flatten Layer
class Flatten(nn.Module):
    def forward(self, x):
        return x.view(x.size(0), -1)

#Main Model
num_classes = len(image_data_train.classes)

class Model:
    def build_model(self):
        model = nn.Sequential(nn.Conv2d(3, 64, kernel_size=5, stride=1), nn.ReLU(), 
                              nn.MaxPool2d(2), nn.Conv2d(64, 64, kernel_size=7, stride=1),
                              nn.ReLU(), nn.MaxPool2d(3), nn.Conv2d(64, 64, kernel_size=7),
                              nn.ReLU(), nn.MaxPool2d(5), Flatten(), nn.Linear(64, 100), 
                              nn.ReLU(), nn.Linear(100, num_classes))
        return model
    
model = Model()
model = model.build_model()

#print(model)
#print(labels_train[0])
#print (image_data_train.samples[0][1])

#Set Optimiser
optimizer = torch.optim.Adagrad(model.parameters(), lr=0.01) # Learn Rate And Optimizer
criterion = nn.CrossEntropyLoss() # Set Loss Type

#Train the Model
def train(epochs):
    model.train()
    losses = []
    for epoch in range(1, epochs+1):
        print(f"Epoch #{epoch}")
        current_loss = 0
        for feature, label in train_loader:
            x = Variable(feature, requires_grad=False).float()
            y = Variable(label, requires_grad=False).long()

            optimizer.zero_grad()
            y_pred = model(x) # Zero the grads
            correct = y_pred.max(1)[1].eq(y).sum()
            print(f"Number of correct classifications: {correct.item()}")
            
            loss = criterion(y_pred, y)
            print(f"Loss: {loss.item()}")
            current_loss += loss.item()
            loss.backward() # Calc Gradient
            optimizer.step() # Change Weights
        losses.append(current_loss) # Log Loss after Epoch Completion
    return losses

#Test The Model
def test():
    model.eval()
    all_preds = []
    all_labels = []
    with torch.no_grad():
        for feature, label in test_loader:
            pred = model(feature)
            all_preds.extend(pred.max(1)[1].numpy())
            all_labels.extend(label.numpy())
    accuracy = accuracy_score(all_labels, all_preds) * 100
    print(f"Accuracy: {accuracy}")

def save():
    model_path = "./"
    print(f"Model saved to {model_path}")
    torch.save(model, model_path)

# Check if GPU is available
if torch.cuda.is_available():
    print("GPU IS AVAILABLE")
else:
    print("UNABLE TO ACCESS GPU")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

print(f"Epoch Size: {len(image_data_train) / 100} iterations")

#list(model.named_parameters())
#len(labels_train)

train(10)
test()
#save()
